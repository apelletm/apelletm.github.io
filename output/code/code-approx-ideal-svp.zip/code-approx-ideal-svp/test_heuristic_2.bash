
echo "res = [];    " > input_test_heuristic_2.sage

echo "Computing the l_2 norm and l_inf norm for vectors output by Laarhoven's algorithm, on our lattice L, for cyclotomic fields of conductor m (using Magma)."

echo "Starting m = 18"
magma -b input:="18 5 5" test_heuristic_2.magma >> input_test_heuristic_2.sage
echo "Starting m = 16"
magma -b input:="16 4 5" test_heuristic_2.magma >> input_test_heuristic_2.sage
echo "Starting m = 36"
magma -b input:="36 2 6" test_heuristic_2.magma >> input_test_heuristic_2.sage
echo "Starting m = 32"
magma -b input:="32 2 8" test_heuristic_2.magma >> input_test_heuristic_2.sage
echo "Starting m = 60"
magma -b input:="60 2 8" test_heuristic_2.magma >> input_test_heuristic_2.sage
echo "Starting m = 27"
magma -b input:="27 3 0" test_heuristic_2.magma >> input_test_heuristic_2.sage
echo "Starting m = 66"
magma -b input:="66 3 2" test_heuristic_2.magma >> input_test_heuristic_2.sage
echo "Starting m = 25"
magma -b input:="25 3 2" test_heuristic_2.magma >> input_test_heuristic_2.sage
echo "Starting m = 46"
magma -b input:="46 1 8" test_heuristic_2.magma >> input_test_heuristic_2.sage
echo "Starting m = 84"
magma -b input:="84 3 7" test_heuristic_2.magma >> input_test_heuristic_2.sage
echo "Starting m = 90"
magma -b input:="90 3 7" test_heuristic_2.magma >> input_test_heuristic_2.sage
echo "Starting m = 78 (this can take some time)"
magma -b input:="78 3 8" test_heuristic_2.magma >> input_test_heuristic_2.sage
echo "Starting m = 72 (this can take some time)"
magma -b input:="72 3 8" test_heuristic_2.magma >> input_test_heuristic_2.sage


echo " 'Computing the ratio l_2 / l_inf for vectors output by Laarhoven's algorithm' done (output written in input_test_heuristic_2.sage)."

echo "Computing the ratio l_2 / l_inf for the vectors previously computed (output by Laarhoven's algorithm) and for Gaussian vectors (using Sage)."

sage test_heuristic_2.sage

echo "done, the resulting figure is saved as 'output_heuristic_2.pdf'."
