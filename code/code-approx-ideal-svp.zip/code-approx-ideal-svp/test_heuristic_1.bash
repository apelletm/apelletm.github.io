
echo " $ m$  & $\nu$ & $\mu^{(2)}(L)$ & $\mu^{(inf)}(L)$ \\\\ " > output_heuristic_1.tex
echo "\hline" >> output_heuristic_1.tex

echo "computing approximate values of the covering radius, in cyclotomic fields of conductor m"

echo "starting m = 18"
magma -b input:=18 test_heuristic_1.magma > tmp_input_heuristic_1.sage
echo "lattice computed"
sage test_heuristic_1.sage >> output_heuristic_1.tex

echo "starting m = 16"
magma -b input:=16 test_heuristic_1.magma > tmp_input_heuristic_1.sage
echo "lattice computed"
sage test_heuristic_1.sage >> output_heuristic_1.tex

echo "starting m = 36"
magma -b input:=36 test_heuristic_1.magma > tmp_input_heuristic_1.sage
echo "lattice computed"
sage test_heuristic_1.sage >> output_heuristic_1.tex

echo "starting m = 40"
magma -b input:=40 test_heuristic_1.magma > tmp_input_heuristic_1.sage
echo "lattice computed"
sage test_heuristic_1.sage >> output_heuristic_1.tex

echo "starting m = 48"
magma -b input:=48 test_heuristic_1.magma > tmp_input_heuristic_1.sage
echo "lattice computed"
sage test_heuristic_1.sage >> output_heuristic_1.tex

echo "starting m = 32"
magma -b input:=32 test_heuristic_1.magma > tmp_input_heuristic_1.sage
echo "lattice computed"
sage test_heuristic_1.sage >> output_heuristic_1.tex

echo "starting m = 27"
magma -b input:=27 test_heuristic_1.magma > tmp_input_heuristic_1.sage
echo "lattice computed"
sage test_heuristic_1.sage >> output_heuristic_1.tex

echo "starting m = 66"
magma -b input:=66 test_heuristic_1.magma > tmp_input_heuristic_1.sage
echo "lattice computed"
sage test_heuristic_1.sage >> output_heuristic_1.tex

echo "starting m = 44"
magma -b input:=44 test_heuristic_1.magma > tmp_input_heuristic_1.sage
echo "lattice computed"
sage test_heuristic_1.sage >> output_heuristic_1.tex

echo "starting m = 70"
magma -b input:=70 test_heuristic_1.magma > tmp_input_heuristic_1.sage
echo "lattice computed"
sage test_heuristic_1.sage >> output_heuristic_1.tex

echo "starting m = 84"
magma -b input:=84 test_heuristic_1.magma > tmp_input_heuristic_1.sage
echo "lattice computed"
sage test_heuristic_1.sage >> output_heuristic_1.tex

echo "starting m = 90"
magma -b input:=90 test_heuristic_1.magma > tmp_input_heuristic_1.sage
echo "lattice computed"
sage test_heuristic_1.sage >> output_heuristic_1.tex

echo "starting m = 78"
magma -b input:=78 test_heuristic_1.magma > tmp_input_heuristic_1.sage
echo "lattice computed"
sage test_heuristic_1.sage >> output_heuristic_1.tex

echo "starting m = 72"
magma -b input:=72 test_heuristic_1.magma > tmp_input_heuristic_1.sage
echo "lattice computed"
sage test_heuristic_1.sage >> output_heuristic_1.tex

rm tmp_input_heuristic_1.sage



echo "done (output written in output_heuristic_1.tex)"
